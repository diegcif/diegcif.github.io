% Approx realizaiton problem

m = 3;
n = 40;
K = m+n-1;
ntries0 = 200;
levels = 5;
noise = (1:levels)'/(2*levels);

for Nmissing = [16,32]  % number of missing entries

if Nmissing==16
    Imissing = vec(([3;5])+(0:5:35)); %count:16
else
    Imissing = vec(([3:10]')+(0:10:30)); %count:32
end

suffix = sprintf('_k%d_miss%d.mat',K,length(Imissing));

% [y,Z0] = table3_gen_input(m,n,ntries0);
load(sprintf('data_table3/input_n%d_m%d.mat',n,m),'y','Z0')
I = isnan(y);
Z0 = Z0(1:ntries0,:);
Z = kron(noise,Z0);
U1 = [y; y + Z];
U1(:,Imissing) = nan;

[Usdp,Eigs] = solve_hankel_sdp(m,n,U1,'mosek');
% save(sprintf('sdp%s',suffix),'Usdp','Eigs')

[Ull] = solve_hankel_slra(m,n,U1,'ll');
[Uqb] = solve_hankel_slra(m,n,U1,'qb');
[Ull2] = solve_hankel_slra(m,n,U1,'ll',true);
[Uqb2] = solve_hankel_slra(m,n,U1,'qb',true);
[Ull3] = solve_hankel_slra(m,n,U1,'ll',true,'spline');
[Uqb3] = solve_hankel_slra(m,n,U1,'qb',true,'spline');
% save(sprintf('ll%s',suffix),'Ull','Ull2','Ull3');
% save(sprintf('qb%s',suffix),'Uqb','Uqb2','Uqb3');

end