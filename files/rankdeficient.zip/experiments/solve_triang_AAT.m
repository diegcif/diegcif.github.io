function [opt,U,z,X] = solve_triang_AAT(P,U1,solver)

if nargin < 3; solver = 'sdpt3'; end

n = size(U1,2);
N = 2*n+1;

u1 = [U1(1,:) U1(2,:)];
% u1 = U1(:)';
G = [eye(N-1) -u1.'; -u1 norm(u1)^2];
E = sparse(N,N,1);

A = zeros(n*(n-1)/2,N*(N+1)/2);

t = 0;
for j=1:n-1
    for k=(j+1):n
        Fjk = fundamental_matrix(P(:,:,j),P(:,:,k));
        At = zeros(N);
        At([k n+k N],[j n+j N]) = Fjk;
        t = t+1;
        A(t,:) = smat2vec(At+At')';
    end
end
A = sparse(A);

[opt,X,x,e] = primal_cvx(A,G,E,solver);
if e>1e-4; warning('solution is not rank one'); end
U = [x(1:n)';x(n+1:2*n)'];
z = round_sol_triang(U,P);

function [opt,X,x,e] = primal_cvx(A,G,E,solver)

N = size(G,1);
cvx_begin sdp quiet
    cvx_solver(solver)
    variable X(N,N) symmetric
    dual variable Q
    y = smat2vec(X);
    minimize(smat2vec(G)'*y);
    smat2vec(E)'*y == 1;
    A*y == 0;
    Q: X >= 0;
cvx_end

opt = cvx_optval;
[x,e] = recoverSol(X);

function [x,e] = recoverSol(X)
[V,E] = eig(full(X)); e=diag(E);
x = sqrt(e(end))*V(:,end);
e = e(end-1);

function F = fundamental_matrix(P,P1)

skew = @(x) [0 -x(3) x(2);x(3) 0 -x(1); -x(2) x(1) 0];

Pinv = pinv(P);
C = null(P);
F = skew(P1*C)*P1*Pinv;
F = F/max(svd(F));

function X = round_sol_triang(U,P)

m = size(U,2);
A = zeros(2*m,4);
for i=1:m
    A(2*i-1:2*i,:) = P(1:2,:,i) - kron(U(1:2,i),P(3,:,i));
end
[~,~,v] = svd(A);
X = v(:,end);