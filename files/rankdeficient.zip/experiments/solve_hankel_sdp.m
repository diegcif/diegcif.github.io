function [Usdp,Eigs] = solve_hankel_sdp(m,n,U1,solver)

k = m+n-1;
ntries = size(U1,1);
PP = hankel_struct(m,n);

neigs = 3;
Usdp = zeros(ntries,k);
Eigs = zeros(ntries,neigs);
for i=1:ntries
    u1 = U1(i,:);
    [opt,u,U,z,X] = sdp_stls(PP,u1,[],solver);
    Usdp(i,:) = u;
    Eigs(i,:) = eigs(X,neigs);
end