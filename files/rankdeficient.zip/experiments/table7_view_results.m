function table7_view_results()

tol_gap = exp(-8);
tol_sing = exp(-6);

npts = 6;          % (6/9/12/15)

prefix = 'data_table7/';

load(sprintf('%sn%d.mat',prefix,npts),'gap2');
load(sprintf('%sKH_n%d.mat',prefix,npts),'sing3');

pct_sdp = 100*sum(gap2<=tol_gap)/size(gap2,1);
pct_KH = 100*sum(sing3<=tol_sing)/size(sing3,1);

fprintf('\nSDP\n')
array2latex(pct_sdp)
fprintf('\nKH\n')
array2latex(pct_KH)
