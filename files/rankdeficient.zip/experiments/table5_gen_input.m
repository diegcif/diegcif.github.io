function [D,d,f,Z0] = table5_gen_input(ntries0)

params = {[1 0 -2],[1 0 0 -1],[1 0 0 0 2]};

g = params{1}; h1 = params{3}; h2 = params{2};
f1 = conv(g,h1); f1 = f1/norm(f1);
f2 = conv(g,h2); f2 = f2/norm(f2);

f = [f1 f2];
d = length(g)-1;
D = [length(f1)-1 length(f2)-1];
n = sum(D)+2;

% NOISE
Z0 = zeros(ntries0,n);
for i=1:ntries0
    rng(i);
    Z0(i,:) = randn(1,n);
end