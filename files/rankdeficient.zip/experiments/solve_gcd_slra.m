% method='ll'   Levenberg–Marquardt
% method='qb'   BFGS

function [Uslra] = solve_gcd_slra(D,d,U1,method)

ntries = size(U1,1);
n = size(U1,2);
assert(n==D(1)+D(2)+2);

s = struct(); %structure
s.m = [D(2)-d+1; D(1)-d+1];
s.n = D(1)+D(2)-d+1;

opts = struct(); %options
opts.maxiter = 5000;
tol = 0; opts.tol = tol; opts.epsrel = tol;
opts.epsabs = tol; opts.epsgrad = tol;
opts.method = method;

f1 = U1(:,1:D(1)+1);
f2 = U1(:,D(1)+2:end);
z1 = zeros(ntries,D(2)-d);
z2 = zeros(ntries,D(1)-d);
P = [z1 f1  z1  z2 f2 z2];

z1 = z1(1,:); z2 = z2(1,:);
f1 = nan*f1(1,:); f2 = nan*f2(1,:);
p = [z1 f1  z1  z2 f2 z2];
I = isnan(p);
s.w = inf(1,size(P,2));
s.w(I) = 1;

k = D(1)+D(2)-2*d+2;

Uslra = zeros(ntries,n);
for i=1:ntries
    p = P(i,:);
    try
        [h, info] = slra(p, s, k-1, opts);
        Uslra(i,:) = h(I);
    catch
        Uslra(i,:) = randn(1,n);
    end
end