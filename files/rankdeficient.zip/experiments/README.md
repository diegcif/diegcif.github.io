This MATLAB code allows to reproduce the numerical experiments from the paper:

  [Cifuentes (2019)](http://www.mit.edu/~diegcif/), "A convex relaxation for structured total least squares", [arXiv:1904.09661](https://arxiv.org/abs/1904.09661)

Requirements
------------
* [CVX](http://cvxr.com/cvx/)
* [stls_sdp](https://github.com/diegcif/stls_sdp)
* [slra](http://slra.github.io/software-slra.html)

Instructions
------------
* The functions *table#_gen_input.m* generate the random data which is used as input for the methods.
* The functions *table#_gen_output.m* solve the underlying optimization problems, producing the output data.
* The folders *data_table#* contain cached input/output data calculated in my personal computer.
* The functions *table#_view_results.m* generate the percentages shown in the tables from the paper, using the cached results.
