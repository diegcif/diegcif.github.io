function [P,PP,z0,U0,U1] = table6_gen_input(n,mode,noise)

% CAMERAS
switch mode
    case 'sphere' % of radius 2
        P = cameras_sphere(n);
    case 'circle' % of radius 2
        P = cameras_circle(n);
    case 'line' %z axis
        P = cameras_line_z(n);
end

% POINTS
z0 = [rand(3,1); 1];

% PICTURES
U0 = photo(P,z0);
if norm(U0(:))>10
    error('bad camera!!!!!')
end

% FRACTIONAL
num1 = permute(P(1,:,:),[3,2,1]);
num2 = permute(P(2,:,:),[3,2,1]);
den = permute(P(3,:,:),[3,2,1]);
PP = fractional_struct([num1;num2],[den;den]);

% NOISE
if nargin>=3
    U1 = U0 + noise*randn(2,n);
end

function P = cameras_sphere(n)
centers = 2*normc(randn(3,n));
P = zeros(3,4,n);
for i=1:n
    c = centers(:,i);
    P(:,:,i) = lookAt(c,[0;0;0]);
end

function P = cameras_circle(n)
centers = 2*normc(randn(2,n));
P = zeros(3,4,n);
for i=1:n
    c = [centers(:,i);0];
    P(:,:,i) = lookAt(c,[0;0;0]);
end

function P = cameras_line_z(n)
P = zeros(3,4,n);
for i=1:n
    c = [2;0;rand()];   % z axis
    P(:,:,i) = lookAt(c,[0;0;0]);
end