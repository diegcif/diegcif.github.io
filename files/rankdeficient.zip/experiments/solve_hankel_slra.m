% method='ll'   Levenberg–Marquardt
% method='qb'   BFGS
function [Uslra] = solve_hankel_slra(m,n,U1,method,use_htls,interpmethod)
if nargin < 5; use_htls = false; end
if nargin < 6; interpmethod = 'linear'; end

K = m+n-1;
ntries = size(U1,1);

s = struct(); %structure
s.m = m; s.n = n;

opts = struct(); %options
tol = 0; opts.maxiter = 5000;
opts.tol = tol; opts.epsrel = tol;
opts.epsabs = tol; opts.epsgrad = tol;
opts.method = method;

Uslra = zeros(ntries,K);
for i=1:ntries
    u1 = U1(i,:);
    if use_htls
        [z,Hu] = htls(m-1,u1,interpmethod);
        opts.Rini = z';
    end
    [h, info] = slra(u1, s, m-1, opts);
    Uslra(i,:) = h';
%     iter(i) = info.iter;
end