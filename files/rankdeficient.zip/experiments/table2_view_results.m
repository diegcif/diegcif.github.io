function table2_view_results()

tol_eigs = 1e-3;
tol_gap = 1e-3;

pct_sdp = nan(5,8);
pct_ll = nan(5,8);
pct_ll2 = nan(5,8);

for n = 3:10; for m = 3:min(7,n)

    load(sprintf('data_table2/sdp_n%d_m%d.mat',n,m),'Usdp','Eigs');
    load(sprintf('data_table2/ll_n%d_m%d.mat',n,m),'Ull','Ull2');

    Isdp = Eigs(:,2)./Eigs(:,1) < tol_eigs;

    gap = sqrt(sum((Ull-Usdp).^2,2));
    gap2 = sqrt(sum((Ull2-Usdp).^2,2));
    Ill = gap < tol_gap;
    Ill2 = gap2 < tol_gap;

    pct_sdp(m-2,n-2) = 100*mean(Isdp);
    pct_ll(m-2,n-2) = 100*mean(Ill);
    pct_ll2(m-2,n-2) = 100*mean(Ill2);

end; end

fprintf('\nSDP\n')
array2latex(pct_sdp)
fprintf('\nLMA\n')
array2latex(pct_ll)
fprintf('\nLMA (initialize HTLS)\n')
array2latex(pct_ll2)