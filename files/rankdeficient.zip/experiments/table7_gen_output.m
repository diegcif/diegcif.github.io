% Resectioning problem

ntries = 400;

noise = [.05 .10 .15 .20 .25];
levels = length(noise);

epsil = [.001 0];

for npts = 6 %[6 15]
fprintf('\nNum Pnts: %d\n', npts)

% DATA
rng(0)
data = cell(1,ntries);
for i=1:ntries
    [PP,~,X0,U0] = table7_gen_input(npts);
    data{i} = {X0,PP,U0};
end

% NOISE
rng(0); Z0 = randn(2,npts,ntries);

gap2 = zeros(ntries,levels);
sing3 = zeros(ntries,levels);
sing4 = zeros(ntries,levels);

tic
for l=1:levels
    fprintf('Noise level: %1.2f\n', noise(l))
    for i=1:ntries
        disp(i)
        di = data{i};
        X0=di{1}; PP=di{2}; U0=di{3};
        Zl = noise(l) * Z0(:,:,i);
        U1 = U0 + Zl;
        u1 = [U1(1,:) U1(2,:)];

        [opt,u,~,z] = sdp_stls(PP,u1,[],'mosek');
        Pr = reshape(z,3,4);
        U = reshape(u,npts,2)';
        gap2(i,l) = norm(photo(Pr,X0)-U);
        if isnan(opt); gap2(i)=inf; end
        
        [Pr3,Ur3,DGram3] = solve_resect_KH(X0,U1,epsil(1),'mosek');
        e = eigs(DGram3,2);
        sing3(i,l) = e(2)/e(1);
        
        [Pr3,Ur3,DGram3] = solve_resect_KH(X0,U1,epsil(2),'mosek');
        e = eigs(DGram3,2);
        sing4(i,l) = e(2)/e(1);
    end
    
end
toc

% save(sprintf('n%d.mat',npts),'data','noise','gap2')
% save(sprintf('KH_n%d.mat',npts),'epsil','noise','sing3','sing4')
end