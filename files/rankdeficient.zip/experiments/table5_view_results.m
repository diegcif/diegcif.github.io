function table5_view_results()

tol_eigs = 1e-3;
tol_gap = 1e-3;

D = [6 5];
d = 2;
levels = 5;
ntries = 200;

prefix = 'data_table5/';

load(sprintf('%ssdp_D%d%d_d%d.mat',prefix,D(1),D(2),d),'Usdp','Eigs');
load(sprintf('%sll_D%d%d_d%d.mat',prefix,D(1),D(2),d),'Ull');
load(sprintf('%sqb_D%d%d_d%d.mat',prefix,D(1),D(2),d),'Uqb');

Isdp = Eigs(:,2)./Eigs(:,1) < tol_eigs;
pct_sdp = 100*means(Isdp,levels,ntries);

Gll = sqrt(sum((Ull-Usdp).^2,2));
Ill = Gll < tol_gap;
pct_ll = 100*means(Ill,levels,ntries);

Gqb = sqrt(sum((Uqb-Usdp).^2,2));
Iqb = Gqb < tol_gap;
pct_qb = 100*means(Iqb,levels,ntries);

fprintf('\nSDP\n')
array2latex(pct_sdp)
fprintf('\nLMA\n')
array2latex(pct_ll)
fprintf('\nBFGS\n')
array2latex(pct_qb)

function g = means(G,levels,ntries)
ntries0 = ceil((length(G)-1)/levels);
GG = reshape(G(2:end),ntries0,levels);
ntries = min(ntries,ntries0);
g = mean(GG(1:ntries,:));
g = [G(1) g];