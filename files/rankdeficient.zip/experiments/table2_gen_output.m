ntries = 2000;

% n = 5; m = 3;
% U1 = table2_gen_input(n+m-1,ntries);

for n = 3:10; for m = 3:min(7,n)

fprintf('\n##############################\n\n');
disp([n,m])
k = m+n-1;

load(sprintf('data_table2/input_k%d.mat',k),'U1');
U1 = U1(1:ntries,:);

[Usdp,Eigs] = solve_hankel_sdp(m,n,U1,'mosek');
[Ull] = solve_hankel_slra(m,n,U1,'ll');
[Ull2] = solve_hankel_slra(m,n,U1,'ll',true);
% save(sprintf('sdp_n%d_m%d.mat',n,m),'Usdp','Eigs');
% save(sprintf('ll_n%d_m%d.mat',n,m),'Ull','Ull2');

end; end