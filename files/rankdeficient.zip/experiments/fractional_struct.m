% Constructs the affine map of a linear fractional program

function PP = fractional_struct(num,den)
[n,k] = size(num);
PP = zeros(k*(n+1),n);
for i=1:n
    Pi = get_matrixFrac_i(n,k,num,den,i);
    PP(:,i) = Pi(:);
end

function Pi = get_matrixFrac_i(n,k,num,den,i)
Pi = spalloc(k,n+1,2*k);
Pi(:,i) = -den(i,:);
Pi(:,n+1) = num(i,:);