% Approximate gcd

ntries0 = 400;
noise = [.05; .1; .15; .2; .25];
levels = length(noise);
D = [6,5]; d = 2;

% [D,d,f,Z0] = table5_gen_input(ntries0);
fin = sprintf('data_table5/input_D%d%d_d%d.mat',D(1),D(2),d);
load(fin,'D','d','f','Z0')

Z0 = Z0(1:ntries0,:);
Z = kron(noise,Z0);
U1 = [f; f + Z];

[Usdp,Eigs] = solve_gcd_sdp(D,d,U1,'mosek');
% save(sprintf('sdp_D%d%d_d%d.mat',D(1),D(2),d),'Usdp','Eigs')

[Ull] = solve_gcd_slra(D,d,U1,'ll');
[Uqb] = solve_gcd_slra(D,d,U1,'qb');
% save(sprintf('ll_D%d%d_d%d.mat',D(1),D(2),d),'Ull');
% save(sprintf('qb_D%d%d_d%d.mat',D(1),D(2),d),'Uqb');