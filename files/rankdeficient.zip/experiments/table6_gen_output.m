% Triangulation problem

mode = 'line';      % (line/circle/sphere)
ntries = 400;

noise = [.1 .2 .3 .4 .5];
levels = length(noise);

for ncam = 3 %[3,5,7]
fprintf('\nNum Cameras: %d\n', ncam)

% DATA
rng(0)
data = cell(1,ntries);
for i=1:ntries
    [P,PP,z0,U0] = table6_gen_input(ncam,mode);
    data{i} = {P,PP,U0};
end

% NOISE
rng(0); Z0 = randn(2,ncam,ntries);

gap = zeros(ntries,levels);
gap2 = zeros(ntries,levels);

tic
for l=1:levels
    fprintf('Noise level: %1.2f\n', noise(l))
    for i=1:ntries
        di = data{i};
        P=di{1}; PP=di{2}; U0=di{3};
        Zl = noise(l) * Z0(:,:,i);
        U1 = U0 + Zl;
        u1 = [U1(1,:) U1(2,:)];

        [opt,u,~,z] = sdp_stls(PP,u1,[],'mosek');
        U = reshape(u,ncam,2)';
        gap(i,l) = norm(photo(P,z) - U);
        if isnan(opt); gap(i)=inf; end

        [opt,U,z] = solve_triang_AAT(P,U1,'mosek');
        gap2(i,l) = norm(photo(P,z) - U);
    end
end
toc

% save(sprintf('%s_n%d.mat',mode,ncam),'data','noise','gap','gap2')
end