function table4_view_results()

tol_eigs = 1e-3;
tol_gap = 1e-3;
levels = 5;
K = 42;

% Nmissng = 16;     %(left hand side of table)
Nmissng = 32;       %(right hand side of table)

suffix = sprintf('_k%d_miss%d.mat',K,Nmissng);
prefix = 'data_table4/';

load(sprintf('%ssdp%s',prefix,suffix),'Usdp','Eigs');
load(sprintf('%sll%s',prefix,suffix),'Ull');
load(sprintf('%sqb%s',prefix,suffix),'Uqb');
load(sprintf('%sll%s',prefix,suffix),'Ull2');
load(sprintf('%sqb%s',prefix,suffix),'Uqb2');
load(sprintf('%sll%s',prefix,suffix),'Ull3');
load(sprintf('%sqb%s',prefix,suffix),'Uqb3');

fprintf('\nSDP\n')
Isdp = Eigs(:,2)./Eigs(:,1) < tol_eigs;
pct_sdp = 100*means(Isdp,levels);
array2latex(pct_sdp)
fprintf('\nLMA\n')
get_pct(Ull,Usdp,levels,tol_gap);
fprintf('\nBFGS\n')
get_pct(Uqb,Usdp,levels,tol_gap);
fprintf('\nLMA (initialize HTLS + linear interp)\n')
get_pct(Ull2,Usdp,levels,tol_gap);
fprintf('\nBFGS (initialize HTLS + linear interp)\n')
get_pct(Uqb2,Usdp,levels,tol_gap);
fprintf('\nLMA (initialize HTLS + cubic slpine)\n')
get_pct(Ull3,Usdp,levels,tol_gap);
fprintf('\nBFGS (initialize HTLS + cubic slpine)\n')
get_pct(Uqb3,Usdp,levels,tol_gap);


function pct = get_pct(Uslra,Usdp,levels,tol_gap)
G = sqrt(sum((Uslra-Usdp).^2,2));
I = G < tol_gap;
pct = 100*means(I,levels);
array2latex(pct)

function g = means(G,levels)
ntries0 = ceil((length(G)-1)/levels);
g = mean(reshape(G(2:end),ntries0,levels));
g = [G(1) g];