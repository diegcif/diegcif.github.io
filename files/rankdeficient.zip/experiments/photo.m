function U = photo(P,X)

if ismatrix(P) %single camera, multiple points
    U = P*X;  
else %multiple cameras, single point
    U = arrayprod(P,X);
end
U = bsxfun(@rdivide,U(1:end-1,:),U(end,:));

function R = arrayprod(P,x)

[l,n,k] = size(P);
R = zeros(l,k);
for i=1:k
    R(:,i) = P(:,:,i)*x;
end