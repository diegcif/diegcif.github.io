function P = lookAt(from, to) 

normalize = @(x) x/norm(x);

from = from(:);
to = to(:);
tmp = randn(3,1);

forward = normalize(to - from);
right = normalize(cross(tmp, forward)); 
up = cross(forward,right); 

R = [right'; up'; forward'];
t = -R*from;
P = [R t];

