function table6_view_results()

tol_gap = exp(-8);

ncam = 7;           % (3/5/7)
mode = 'sphere';    % (line/circle/sphere)

prefix = 'data_table6/';

load(sprintf('%s%s_n%d.mat',prefix,mode,ncam),'gap','gap2');

pct_sdp = 100*sum(gap<=tol_gap)/size(gap,1);
pct_AAT = 100*sum(gap2<=tol_gap)/size(gap2,1);

fprintf('\nSDP\n')
array2latex(pct_sdp)
fprintf('\nAAT\n')
array2latex(pct_AAT)