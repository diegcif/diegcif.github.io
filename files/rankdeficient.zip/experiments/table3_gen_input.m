function [y,Z0] = table3_gen_input(m,n,ntries0)

K = m+n-1;

% NOISE
Z0 = zeros(ntries0,K);
for i=1:ntries0
    rng(i);
    Z0(i,:) = randn(1,K);
end
% rng(0); Z0 = randn(ntries0,n);

% LTI SYSTEM
dt = 1.0;
num = [1 -1];
if m==3; den = [1 -8/5 4/5];
elseif m==4; den = [1 -6/5 6/5 -4/5];
else; error('not implemented');
end
sys = tf(num,den,dt);

% RESPONSE
impulse(sys,K*dt); pause(.1);
[y,t] = impulse(sys,K*dt);
y = y(2:K+1)';