function [Usdp,Eigs] = solve_gcd_sdp(D,d,U1,solver)

ntries = size(U1,1);
[PP,K] = sylvester_struct(D,d);

neigs = 3;
Usdp = zeros(ntries,K);
Eigs = zeros(ntries,neigs);
for i=1:ntries
    u1 = U1(i,:);
    [opt,u,U,z,X] = sdp_stls(PP,u1,[],solver);
    Usdp(i,:) = u;
%     if isnan(opt); Eigs(i,:)=inf; end
    Eigs(i,:) = eigs(X,neigs);
end