function U1 = table2_gen_input(n,ntries)
U1 = zeros(ntries,n);
for i=1:ntries
    rng(i);
    u1 = randn(1,n);
    U1(i,:) = u1/norm(u1);
end