function [PP,P0,Z0,U0,U1] = table7_gen_input(m,noise)

P0 = camera_sphere();

%Points
Z0 = [rand(3,m); ones(1,m)];

%Images
U0 = photo(P0,Z0);

num1 = kron(Z0',[1 0 0]);
num2 = kron(Z0',[0 1 0]);
den = kron(Z0',[0 0 1]);
PP = fractional_struct([num1;num2],[den;den]);

% NOISE
if nargin>=2
    U1 = U0 + noise*randn(2,m);
end

function P = camera_sphere()
c = randn(3,1);
c = 2*c/norm(c);
P = lookAt(c,[0;0;0]);
