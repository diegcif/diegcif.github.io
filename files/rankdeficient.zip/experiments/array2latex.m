function array2latex(M)

pct = true;

m = size(M,1);
n = size(M,2);

if ~pct
for i=1:m
    for j = 1:n
        if j>=i
            fprintf('& %3.0f ',M(i,j))
        else
            fprintf('   ')
        end
    end
    fprintf('\\\\\n')
end
else
for i=1:m
    for j = 1:n
        if j>=i
            fprintf('& %3.0f\\pct ',M(i,j))
        else
            fprintf('&         ')
        end
    end
    fprintf('\n')
end
end